<?php
if (!defined('ABSPATH')) { exit; }

class PdfCraft_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'pdfcraft_pdf_editor'; }
    public function get_title() { return esc_html__('PdfCraft PDF Editor', 'pdfcraft-responsive'); }
    public function get_icon() { return 'eicon-document-file'; }
    public function get_categories() { return array('general'); }
    public function get_keywords() { return array('pdf', 'pdfcraft', 'editor', 'document', 'pdf tools'); }
    public function get_style_depends() { return array('pdfcraft-responsive'); }

    protected function register_controls() {
        $this->start_controls_section('pdfcraft_content_section', array(
            'label' => esc_html__('PDF Editor', 'pdfcraft-responsive'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ));
        $this->add_control('title', array(
            'label' => esc_html__('Widget Title', 'pdfcraft-responsive'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => esc_html__('PdfCraft PDF Editor', 'pdfcraft-responsive'),
            'label_block' => true,
        ));
        $this->add_control('height', array(
            'label' => esc_html__('Editor Height', 'pdfcraft-responsive'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '78vh',
            'options' => array('60vh' => '60vh', '70vh' => '70vh', '78vh' => '78vh', '85vh' => '85vh', '90vh' => '90vh', '700px' => '700px', '800px' => '800px', '900px' => '900px'),
        ));
        $this->add_control('min_height', array(
            'label' => esc_html__('Minimum Height', 'pdfcraft-responsive'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '520px',
            'options' => array('420px' => '420px', '480px' => '480px', '520px' => '520px', '600px' => '600px'),
        ));
        $this->add_control('show_header', array(
            'label' => esc_html__('Show Header', 'pdfcraft-responsive'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__('Show', 'pdfcraft-responsive'),
            'label_off' => esc_html__('Hide', 'pdfcraft-responsive'),
            'return_value' => 'yes',
            'default' => 'yes',
        ));
        $this->add_control('show_note', array(
            'label' => esc_html__('Show Mobile Tip', 'pdfcraft-responsive'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => 'yes',
        ));
        $this->add_control('open_button', array(
            'label' => esc_html__('Show Open Full Screen Link', 'pdfcraft-responsive'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => 'yes',
            'condition' => array('show_header' => 'yes'),
        ));
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $attrs = array(
            'title' => isset($settings['title']) ? $settings['title'] : 'PdfCraft PDF Editor',
            'height' => isset($settings['height']) ? $settings['height'] : '78vh',
            'min_height' => isset($settings['min_height']) ? $settings['min_height'] : '520px',
            'show_header' => !empty($settings['show_header']) ? 'yes' : 'no',
            'show_note' => !empty($settings['show_note']) ? 'yes' : 'no',
            'open_button' => !empty($settings['open_button']) ? 'yes' : 'no',
        );
        echo do_shortcode('[pdfcraft ' . $this->attrs_to_shortcode($attrs) . ']'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    private function attrs_to_shortcode($attrs) {
        $parts = array();
        foreach ($attrs as $key => $value) {
            $parts[] = sanitize_key($key) . '="' . esc_attr($value) . '"';
        }
        return implode(' ', $parts);
    }
}
