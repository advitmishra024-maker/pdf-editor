<?php
/**
 * Plugin Name: PdfCraft Responsive PDF Editor for Elementor
 * Description: Adds a responsive PdfCraft PDF editor widget to Elementor, plus a WordPress shortcode.
 * Version: 1.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: MIT OR Apache-2.0
 * Text Domain: pdfcraft-responsive
 */
if (!defined('ABSPATH')) { exit; }

final class PdfCraft_Responsive_Plugin {
    const VERSION = '1.1.0';

    public function __construct() {
        add_shortcode('pdfcraft', array($this, 'render_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_action('elementor/widgets/register', array($this, 'register_elementor_widget'));
    }

    public function register_assets() {
        wp_register_style('pdfcraft-responsive', plugins_url('assets/pdfcraft-responsive.css', __FILE__), array(), self::VERSION);
    }

    public function register_elementor_widget($widgets_manager) {
        if (!did_action('elementor/loaded')) { return; }
        require_once __DIR__ . '/includes/class-pdfcraft-elementor-widget.php';
        $widgets_manager->register(new \PdfCraft_Elementor_Widget());
    }

    public function render_shortcode($atts = array()) {
        $atts = shortcode_atts(array(
            'height' => '78vh',
            'min_height' => '520px',
            'title' => 'PdfCraft PDF Editor',
            'show_header' => 'yes',
            'show_note' => 'yes',
            'open_button' => 'yes',
        ), $atts, 'pdfcraft');

        $height = $this->safe_css_size($atts['height'], '78vh');
        $min_height = $this->safe_css_size($atts['min_height'], '520px');
        $show_header = strtolower((string) $atts['show_header']) !== 'no';
        $show_note = strtolower((string) $atts['show_note']) !== 'no';
        $open_button = strtolower((string) $atts['open_button']) !== 'no';

        wp_enqueue_style('pdfcraft-responsive');
        $src = plugins_url('assets/index.html', __FILE__);
        $id = wp_unique_id('pdfcraft-frame-');
        ob_start(); ?>
        <section class="pdfcraft-embed" style="--pdfcraft-height:<?php echo esc_attr($height); ?>;--pdfcraft-min-height:<?php echo esc_attr($min_height); ?>" aria-label="<?php echo esc_attr($atts['title']); ?>">
          <?php if ($show_header) : ?>
          <div class="pdfcraft-embed__topbar">
            <span class="pdfcraft-embed__mark" aria-hidden="true">P</span>
            <div class="pdfcraft-embed__heading"><strong><?php echo esc_html($atts['title']); ?></strong><span>PDF tools in your browser</span></div>
            <?php if ($open_button) : ?><a class="pdfcraft-embed__open" href="<?php echo esc_url($src); ?>" target="_blank" rel="noopener noreferrer">Open full screen <span aria-hidden="true">↗</span></a><?php endif; ?>
          </div>
          <?php endif; ?>
          <div class="pdfcraft-embed__viewport"><iframe id="<?php echo esc_attr($id); ?>" src="<?php echo esc_url($src); ?>" title="<?php echo esc_attr($atts['title']); ?>" loading="lazy" allow="fullscreen" allowfullscreen></iframe></div>
          <?php if ($show_note) : ?><p class="pdfcraft-embed__note">For the best experience on a phone, rotate to landscape or open the editor full screen.</p><?php endif; ?>
        </section>
        <?php return ob_get_clean();
    }

    private function safe_css_size($value, $fallback) {
        $value = trim((string) $value);
        return preg_match('/^[0-9.]+(px|vh|vw|rem|em|%)$/', $value) ? $value : $fallback;
    }
}
new PdfCraft_Responsive_Plugin();
