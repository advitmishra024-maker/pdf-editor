=== PdfCraft Responsive PDF Editor for Elementor ===
Contributors: pdfcraft
Tags: pdf, elementor, pdf editor, responsive, document
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: MIT OR Apache-2.0

Embed the PdfCraft PDF workbench in WordPress with a responsive Elementor widget or shortcode.

== Installation ==
1. In WordPress, go to Plugins > Add New Plugin > Upload Plugin.
2. Upload this ZIP and activate it.
3. Make sure Elementor is installed and active to use the Elementor widget.
4. Open a page with Elementor, search for “PdfCraft PDF Editor”, and drag the widget onto the page.
5. Configure the title, editor height, minimum height, header, mobile tip, and full-screen link in the Content panel.

== Shortcode ==
Use [pdfcraft] in any page, post, or shortcode widget.

Available attributes:
[pdfcraft title="Online PDF Editor" height="80vh" min_height="600px" show_header="yes" show_note="yes" open_button="yes"]

== Notes ==
The Elementor widget is registered when Elementor is active. Without Elementor, the shortcode remains available.
The PDF editor application runs inside an iframe, keeping its own runtime separate from the WordPress theme and Elementor layout.
